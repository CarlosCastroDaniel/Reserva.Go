/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author devmat
 */
public class Selecao {
    private int idfuncionario;
    private int idchave;
    private String nomeFuncionario;
    private String nomeSala;         
    private String periodo;
    private String cpfFuncionario;

    public Selecao(int idfuncionario, int idchave, String nomeFuncionario, String nomeSala, String periodo, String cpfFuncionario) {
        this.idfuncionario = idfuncionario;
        this.idchave = idchave;
        this.nomeFuncionario = nomeFuncionario;
        this.nomeSala = nomeSala;
        this.periodo = periodo;
        this.cpfFuncionario = cpfFuncionario;
    }

    public Selecao() {
    }

    public int getIdfuncionario() {
        return idfuncionario;
    }

    public void setIdfuncionario(int idfuncionario) {
        this.idfuncionario = idfuncionario;
    }

    public int getIdchave() {
        return idchave;
    }

    public void setIdchave(int idchave) {
        this.idchave = idchave;
    }

    public String getNomeFuncionario() {
        return nomeFuncionario;
    }

    public void setNomeFuncionario(String nomeFuncionario) {
        this.nomeFuncionario = nomeFuncionario;
    }

    public String getNomeSala() {
        return nomeSala;
    }

    public void setNomeSala(String nomeSala) {
        this.nomeSala = nomeSala;
    }

    public String getPeriodo() {
        return periodo;
    }

    public void setPeriodo(String periodo) {
        this.periodo = periodo;
    }

    public String getCpfFuncionario() {
        return cpfFuncionario;
    }

    public void setCpfFuncionario(String cpfFuncionario) {
        this.cpfFuncionario = cpfFuncionario;
    }
    
    


    
    
}
