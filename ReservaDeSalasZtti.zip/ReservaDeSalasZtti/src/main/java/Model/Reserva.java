/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODEL;

import java.util.Date;

/**
 *
 * @author devmat
 */
public class Reserva {
    private int idReserva;
    private int idFuncionario;
    private int idChave;
    private String dataReserva;
    private String dataEntrega;
    private String horaReserva;
    private String horaEntrega;
    private boolean entregue;

    public Reserva() {
    }

    public Reserva(int idReserva, int idFuncionario, int idChave, String dataReserva, String dataEntrega, String horaReserva, String horaEntrega, boolean entregue) {
        this.idReserva = idReserva;
        this.idFuncionario = idFuncionario;
        this.idChave = idChave;
        this.dataReserva = dataReserva;
        this.dataEntrega = dataEntrega;
        this.horaReserva = horaReserva;
        this.horaEntrega = horaEntrega;
        this.entregue =  entregue;
    }

    public Reserva(int idFuncionario, int idChave, String dataReserva, String dataEntrega, String horaReserva, String horaEntrega, boolean entregue) {
        this.idFuncionario = idFuncionario;
        this.idChave = idChave;
        this.dataReserva = dataReserva;
        this.dataEntrega = dataEntrega;
        this.horaReserva = horaReserva;
        this.horaEntrega = horaEntrega;
        this.entregue =  entregue;
    }

    public Reserva(int idFuncionario, int idChave, String dataReserva, String horaReserva, boolean entregue) {
        this.idFuncionario = idFuncionario;
        this.idChave = idChave;
        this.dataReserva = dataReserva;
        this.horaReserva = horaReserva;
        this.entregue =  entregue;
    }

    public int getIdReserva() {
        return idReserva;
    }

    public void setIdReserva(int idReserva) {
        this.idReserva = idReserva;
    }

    public int getIdFuncionario() {
        return idFuncionario;
    }

    public void setIdFuncionario(int idFuncionario) {
        this.idFuncionario = idFuncionario;
    }

    public int getIdChave() {
        return idChave;
    }

    public void setIdChave(int idChave) {
        this.idChave = idChave;
    }

    public String getDataReserva() {
        return dataReserva;
    }

    public void setDataReserva(String dataReserva) {
        this.dataReserva = dataReserva;
    }

    public String getDataEntrega() {
        return dataEntrega;
    }

    public void setDataEntrega(String dataEntrega) {
        this.dataEntrega = dataEntrega;
    }

    public String getHoraReserva() {
        return horaReserva;
    }

    public void setHoraReserva(String horaReserva) {
        this.horaReserva = horaReserva;
    }

    public String getHoraEntrega() {
        return horaEntrega;
    }

    public void setHoraEntrega(String horaEntrega) {
        this.horaEntrega = horaEntrega;
    }

    @Override
    public String toString() {
        return "Reserva{" + "idReserva=" + idReserva + ", idFuncionario=" + idFuncionario + ", idChave=" + idChave + ", dataReserva=" + dataReserva + ", dataEntrega=" + dataEntrega + ", horaReserva=" + horaReserva + ", horaEntrega=" + horaEntrega + '}';
    }

    public boolean isEntregue() {
        return entregue;
    }

    public void setEntregue(boolean entregue) {
        this.entregue = entregue;
    }
    
   
    
    

}

