/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author devmat
 */
public class ReservaDetalhes {
    private int idReserva;
    private String nomeFuncionario;
    private String nomeSala;
    private String dataDeReserva;
    private String horaReserva;
    private boolean entregue;

    public ReservaDetalhes(int idReserva, String nomeFuncionario, String nomeSala, String dataDeReserva, String horaReserva, boolean entregue) {
        this.idReserva = idReserva;
        this.nomeFuncionario = nomeFuncionario;
        this.nomeSala = nomeSala;
        this.dataDeReserva = dataDeReserva;
        this.horaReserva = horaReserva;
        this.entregue = entregue;
    }

    public ReservaDetalhes() {
    }
    
    

    public int getIdReserva() {
        return idReserva;
    }

    public void setIdReserva(int idReserva) {
        this.idReserva = idReserva;
    }

    public String getNomeFuncionario() {
        return nomeFuncionario;
    }

    public void setNomeFuncionario(String nomeFuncionario) {
        this.nomeFuncionario = nomeFuncionario;
    }

    public String getNomeSala() {
        return nomeSala;
    }

    public void setNomeSala(String nomeSala) {
        this.nomeSala = nomeSala;
    }

    public String getDataDeReserva() {
        return dataDeReserva;
    }

    public void setDataDeReserva(String dataDeReserva) {
        this.dataDeReserva = dataDeReserva;
    }

    public String getHoraReserva() {
        return horaReserva;
    }

    public void setHoraReserva(String horaReserva) {
        this.horaReserva = horaReserva;
    }

    public boolean isEntregue() {
        return entregue;
    }

    public void setEntregue(boolean entregue) {
        this.entregue = entregue;
    }
    
    
    
    
    
            
}
