/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODEL;

/**
 *
 * @author devmat
 */
public class Funcionario {
    private int idFuncionario;
    private String nomeCargo;
    private String nomeFuncionario;
    private String cpfFuncionario;
 
    public Funcionario() {
    }

    public Funcionario(int idFuncionario, String nomeCargo, String nomeFuncionario, String cpfFuncionario) {
        this.idFuncionario = idFuncionario;
        this.nomeCargo = nomeCargo;
        this.nomeFuncionario = nomeFuncionario;
        this.cpfFuncionario = cpfFuncionario;
    }

    public Funcionario(String nomeCargo, String nomeFuncionario, String cpfFuncionario) {
        this.nomeCargo = nomeCargo;
        this.nomeFuncionario = nomeFuncionario;
        this.cpfFuncionario = cpfFuncionario;
    }
    
    

    public int getIdFuncionario() {
        return idFuncionario;
    }

    public void setIdFuncionario(int idFuncionario) {
        this.idFuncionario = idFuncionario;
    }

    public String getNomeCargo() {
        return nomeCargo;
    }

    public void setNomeCargo(String nomeCargo) {
        this.nomeCargo = nomeCargo;
    }

    public String getNomeFuncionario() {
        return nomeFuncionario;
    }

    public void setNomeFuncionario(String nomeFuncionario) {
        this.nomeFuncionario = nomeFuncionario;
    }

    public String getCpfFuncionario() {
        return cpfFuncionario;
    }

    public void setCpfFuncionario(String cpfFuncionario) {
        this.cpfFuncionario = cpfFuncionario;
    }
    
    

   
   
}


