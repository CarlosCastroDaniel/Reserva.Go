/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODEL;

/**
 *
 * @author devmat
 */
public class Chave {
    private int idChave;
    private String  nomeSala;
    private boolean disponivel;

    public Chave() {
    }

    public Chave(String nomeSala, boolean disponivel) {
        this.nomeSala = nomeSala;
        this.disponivel = disponivel;
    }

    public Chave(int idChave, String nomeSala, boolean disponivel) {
        this.idChave = idChave;
        this.nomeSala = nomeSala;
        this.disponivel = disponivel;
    }

    public int getIdChave() {
        return idChave;
    }

    public void setIdChave(int idChave) {
        this.idChave = idChave;
    }

    public String getNomeSala() {
        return nomeSala;
    }

    public void setNomeSala(String nomeSala) {
        this.nomeSala = nomeSala;
    }

    public boolean isDisponivel() {
        return disponivel;
    }

    public void setDisponivel(boolean disponivel) {
        this.disponivel = disponivel;
    }

    
}

