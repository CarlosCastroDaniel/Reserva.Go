/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import MODEL.Chave;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Carlos Zetti
 */
public class ChaveController {
    
    public boolean inserirChave(Chave chave) {
        String sql = "INSERT INTO Chave (nomeSala, disponivel) VALUES (?, ?)";

        try (Connection conexao = new Conexao().getConexao();
             PreparedStatement pstmt = conexao.prepareStatement(sql)) {
            
            pstmt.setString(1, chave.getNomeSala());
            pstmt.setBoolean(2, chave.isDisponivel());
            pstmt.executeUpdate();
            return true;
            
        } catch (SQLException e) {
            return false;
        }
    }
    
    public List<Chave> listaChave(){
        String query = "SELECT * FROM Chave";
        // criando uma lista para capturar os dados do select
        List<Chave> lista = new ArrayList<>();
        // criando o try catch
        try(Connection conexao = new Conexao().getConexao();
        PreparedStatement pstm = conexao.prepareStatement(query);
         ResultSet resultset = pstm.executeQuery() ){
            
            // passando o valor do select para um objeto produto
            // enquanto resultset for diferente de null
            while(resultset.next()){
                // receba o valor e cadastre em produto
                  Chave c = new Chave();
                  c.setIdChave(resultset.getInt("idChave"));
                  c.setNomeSala(resultset.getString("nomeSala"));
                  c.setDisponivel(resultset.getBoolean("disponivel"));
                  // jogando o produto dentro da lista
                  lista.add(c);
             }// fim do while
            return lista;
           
        }catch(SQLException e){
            System.err.print("Erro ao listar chaves "+e);
            return null;
        }// final do try catch
    }// fim do metodo listarProdutos()
    
}
