/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Selecao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author devmat
 */
public class SelecaoController {
    
    
 
    public boolean excluirSelecao(int idFuncionario, int idChave) {
        String query = "DELETE FROM selecaoChavesFuncionario WHERE idFuncionario = ? AND idChave = ?";
        try (Connection conexao = new Conexao().getConexao();
             PreparedStatement pstmt = conexao.prepareStatement(query)) {
            pstmt.setInt(1, idFuncionario);
            pstmt.setInt(2, idChave);
            int linhasAfetadas = pstmt.executeUpdate();
            return linhasAfetadas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

  

    
    // Método para listar seleções
public List<Selecao> listaSelecao() { 
    String query = "SELECT f.nomeFuncionario, c.nomeSala, s.periodo, f.cpfFuncionario, s.idFuncionario, s.idChave " + 
                   "FROM selecaoChavesFuncionario s " + 
                   "JOIN Funcionario f ON s.idFuncionario = f.idFuncionario " + 
                   "JOIN Chave c ON s.idChave = c.idChave"; 
    
    List<Selecao> lista = new ArrayList<>(); 
    
    try (Connection conexao = new Conexao().getConexao(); 
         PreparedStatement pstm = conexao.prepareStatement(query); 
         ResultSet resultSet = pstm.executeQuery()) { 
        
        while (resultSet.next()) { 
            Selecao selecao = new Selecao(); 
            selecao.setNomeFuncionario(resultSet.getString("nomeFuncionario")); 
            selecao.setNomeSala(resultSet.getString("nomeSala")); 
            selecao.setPeriodo(resultSet.getString("periodo")); 
            selecao.setCpfFuncionario(resultSet.getString("cpfFuncionario")); 
            selecao.setIdfuncionario(resultSet.getInt("idFuncionario")); 
            selecao.setIdchave(resultSet.getInt("idChave")); 
            lista.add(selecao); 
        } 
    } catch (SQLException e) { 
        System.err.print("Erro ao listar seleções: " + e); 
    } 
    
    return lista; 
}

    
    public boolean adicionarSelecao(Selecao selecao) {
        String query = "INSERT INTO selecaoChavesFuncionario (idfuncionario, idchave, periodo)VALUES (?, ?, ?);";
    
        // Tentando executar o código para adicionar a seleção
        try (Connection conexao = new Conexao().getConexao();
             PreparedStatement pstm = conexao.prepareStatement(query)) {
        
            // Definindo os parâmetros da consulta (valores do objeto selecao)
            pstm.setInt(1, selecao.getIdfuncionario());
            pstm.setInt(2, selecao.getIdchave());
            pstm.setString(3, selecao.getPeriodo());
        
            // Executando a inserção no banco de dados
            int rowsAffected = pstm.executeUpdate();
            // Retorna true se a inserção for bem-sucedida, caso contrário false
            return rowsAffected > 0;
        
        } catch (SQLException e) {
            System.err.println("Erro ao adicionar seleção: " + e);
            return false;
        }
    }
}
