package Controller;

import MODEL.Reserva;
import Model.ReservaDetalhes;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ReservaController {

    public boolean inserirReserva(Reserva r) {
        try (Connection conexao = new Conexao().getConexao();
             PreparedStatement pstmt = conexao.prepareStatement(
                     "INSERT INTO Reservas (idFuncionario, idChave, dataDeReserva, horaReserva, entregue) VALUES (?, ?, ?, ?, ?)"
             )) {
            pstmt.setInt(1, r.getIdFuncionario());
            pstmt.setInt(2, r.getIdChave());
            pstmt.setString(3, r.getDataReserva());
            pstmt.setString(4, r.getHoraReserva());
            pstmt.setBoolean(5, r.isEntregue());
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<ReservaDetalhes> listaReservaDetalhesNaoEntregue() {
        String query = "SELECT * FROM ReservaDetalhes where entregue = false;";
        List<ReservaDetalhes> lista = new ArrayList<>();
        try (Connection conexao = new Conexao().getConexao();
             PreparedStatement pstm = conexao.prepareStatement(query);
             ResultSet resultset = pstm.executeQuery()) {

            while (resultset.next()) {
                ReservaDetalhes r = new ReservaDetalhes();
                r.setIdReserva(resultset.getInt("idReserva"));
                r.setNomeFuncionario(resultset.getString("nomeFuncionario"));
                r.setNomeSala(resultset.getString("nomeSala"));
                r.setDataDeReserva(resultset.getString("dataDeReserva"));
                r.setHoraReserva(resultset.getString("horaReserva"));
                r.setEntregue(resultset.getBoolean("entregue"));

                lista.add(r);
            }
            return lista;

        } catch (SQLException e) {
            System.err.print("Erro ao listar Reservas" + e);
            return null;
        }
    }

    public boolean devolucao(int idReservaSelect, String data, String hora) {
        String query = "UPDATE Reservas SET entregue = true,  dataEntrega = ?, horaEntrega = ? WHERE idReserva = ?";

        try (Connection conexao = new Conexao().getConexao();
             PreparedStatement pstmt = conexao.prepareStatement(query)) {

            pstmt.setString(1, data);
            pstmt.setString(2, hora);
            pstmt.setInt(3, idReservaSelect);

            int linhasAfetadas = pstmt.executeUpdate();
            return linhasAfetadas > 0;

        } catch (SQLException e) {
            System.err.println("Erro ao realizar devolução: " + e.getMessage());
            return false;
        }
    }

    public boolean atualizarReservasInfo() {
        try (Connection conexao = new Conexao().getConexao()) { 
            verificarECriarTabelaReservaInfo(); // Verificar e criar a tabela se necessário

            // Limpar a tabela antes de inserir novos dados
            String limparQuery = "DELETE FROM tabelaReservaInfo"; 
            try (PreparedStatement pstmt = conexao.prepareStatement(limparQuery)) { 
                pstmt.executeUpdate(); 
            }

            String query = "INSERT INTO tabelaReservaInfo (idChave, nomeSala, disponibilidade) " + 
                           "SELECT c.idChave, c.nomeSala, 'Disponível' AS disponibilidade " + 
                           "FROM Chave c LEFT JOIN selecaoChavesFuncionario s ON c.idChave = s.idChave " + 
                           "WHERE s.idChave IS NULL";

            try (PreparedStatement pstmt = conexao.prepareStatement(query)) { 
                pstmt.executeUpdate(); 
                return true; 
            } catch (SQLException e) { 
                e.printStackTrace(); 
                return false; 
            } 
        } catch (SQLException e) { 
            e.printStackTrace(); 
            return false; 
        }
    }

    
    
    
   // Método para obter os dados das reservas
public List<Object[]> getDadosReservas() throws SQLException { 
    List<Object[]> dadosReservas = new ArrayList<>(); 
    
    String query = "SELECT idFuncionario, nomeFuncionario, nomeSala, disponibilidade, horaReserva, horaEntrega, entregue FROM tabelaReservasInfo"; 
    
    try (Connection conexao = new Conexao().getConexao(); 
         PreparedStatement pstmt = conexao.prepareStatement(query); 
         ResultSet rs = pstmt.executeQuery()) { 
        
        while (rs.next()) { 
            Object[] linha = { 
                rs.getInt("idFuncionario"), 
                rs.getString("nomeFuncionario"), 
                rs.getString("nomeSala"), 
                rs.getString("disponibilidade"), 
                rs.getString("horaReserva"), 
                rs.getString("horaEntrega"), 
                rs.getBoolean("entregue") ? "Sim" : "Não" 
            }; 
            dadosReservas.add(linha); 
        } 
    } 
    
    return dadosReservas; 
}

    public boolean verificarReservaAtiva(int idChave) {
        String query = "SELECT COUNT(*) FROM Reservas WHERE idChave = ? AND entregue = false";

        try (Connection conexao = new Conexao().getConexao();
             PreparedStatement pstmt = conexao.prepareStatement(query)) {
            pstmt.setInt(1, idChave);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Método para verificar e criar a tabela se necessário
    private void verificarECriarTabelaReservaInfo() throws SQLException {
        String query = "CREATE TABLE IF NOT EXISTS tabelaReservaInfo (" +
                       "idReserva SERIAL PRIMARY KEY," +
                       "nomeFuncionario VARCHAR(255) NOT NULL," +
                       "nomeSala VARCHAR(255) NOT NULL," +
                       "entregue BOOLEAN NOT NULL)";
        try (Connection conexao = new Conexao().getConexao();
             PreparedStatement pstmt = conexao.prepareStatement(query)) {
            pstmt.execute();
        }
    }
  
    // Método para adicionar a coluna 'entregue' na tabela 'tabelaReservaInfo'
    public boolean adicionarColunaEntregue() {
        String query = "ALTER TABLE tabelaReservaInfo " +
                       "ADD COLUMN entregue BOOLEAN NOT NULL DEFAULT false";

        try (Connection conexao = new Conexao().getConexao();
             PreparedStatement pstmt = conexao.prepareStatement(query)) {
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Outros métodos existentes...
}
