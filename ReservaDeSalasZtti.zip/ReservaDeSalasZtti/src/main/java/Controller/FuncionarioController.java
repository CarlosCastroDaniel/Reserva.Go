/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import MODEL.Funcionario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author devmat
 */
public class FuncionarioController {
        public boolean insert(Funcionario f) throws SQLException {
        // Obtém a conexão do banco de dados
        try (Connection conexao = new Conexao().getConexao();
             // Prepara a instrução SQL para inserção
             PreparedStatement pstmt = conexao.prepareStatement(
                "INSERT INTO Funcionario (nomeCargo, nomeFuncionario, cpfFuncionario) VALUES (?, ?, ?)"
             )) {
            // Define os parâmetros da instrução SQL
            pstmt.setString(1, f.getNomeCargo());
            pstmt.setString(2, f.getNomeFuncionario());
            pstmt.setString(3, f.getCpfFuncionario());
    
            // Executa a instrução SQL
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
             // Trata possíveis exceções de SQL
             System.err.println("Não foi possivel inserir Funcionario");
             return false;
        }
    }   
        
        
    public List<Funcionario> listaFuncionario(){
        String query = "SELECT * FROM Funcionario;";
        // criando uma lista para capturar os dados do select
        List<Funcionario> lista = new ArrayList<>();
        // criando o try catch
        try(Connection conexao = new Conexao().getConexao();
        PreparedStatement pstm = conexao.prepareStatement(query);
         ResultSet resultset = pstm.executeQuery() ){
            
            // passando o valor do select para um objeto produto
            // enquanto resultset for diferente de null
            while(resultset.next()){
                // receba o valor e cadastre em produto
                 Funcionario f = new Funcionario();
                  f.setIdFuncionario(resultset.getInt("idfuncionario"));
                  f.setNomeFuncionario(resultset.getString("nomeFuncionario"));
                  f.setNomeCargo(resultset.getString("nomeCargo"));
                  f.setCpfFuncionario(resultset.getString("cpfFuncionario"));
                  // jogando o produto dentro da lista
                  lista.add(f);
             }// fim do while
            return lista;
           
        }catch(SQLException e){
            System.err.print("Erro ao listar"+e);
            return null;
        }
    }
        
}
