/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package View;

import Controller.ChaveController;
import Controller.Conexao;
import Controller.FuncionarioController;
import Controller.SelecaoController;
import MODEL.Chave;
import MODEL.Funcionario;
import Model.Selecao;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;

/**
 *
 * @author UFNT
 */
public class MenuCooped extends javax.swing.JFrame {

    /**
     * Creates new form Menu
     */
    public MenuCooped() {
        setTitle("COPED");
        setSize(900, 700); // Define o tamanho da janela
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false); // Impede redimensionamento da janela
        
        initComponents();
        
        
        // Centraliza a janela no centro da tela
        setLocationRelativeTo(null);
        // Torna a janela visível
        setVisible(true);
       // aplicarLimitacaoDeCaracteres();
        
        painelInicial.setVisible(true);
        painelSelecao.setVisible(false);
        PainelcadastrosSalaFunc.setVisible(false);
        painelTodasSelecao.setVisible(false);
     campoNomeFuncCadastro = new JTextField();
     campoCargo = new JTextField(); 
    campoCpfCadastro = new JTextField();
       
    }
      public void limparCampoCadastroFunc(){
       campoNomeFuncCadastro.setText("");
        campoCargo.setText("");
        campoCpfCadastro.setText("");
    }
  /*  private void aplicarLimitacaoDeCaracteres() {
 // Adicionando um filtro de documento para limitar o CPF a 15 caracteres
((AbstractDocument) campoCpfCadastro.getDocument()).setDocumentFilter(new DocumentFilter() {
    @Override
    public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) 
            throws BadLocationException {
        if (fb.getDocument().getLength() + text.length() - length >= 14) {
            super.replace(fb, offset, length, text, attrs);
        }
    }

    @Override
    public void insertString(FilterBypass fb, int offset, String text, AttributeSet attr) 
            throws BadLocationException {
        if (fb.getDocument().getLength() + text.length() >= 14) {
            super.insertString(fb, offset, text, attr);
        }
    }
});
}*/

// Configuração de layout e adição de outros componentes
// ...

// Código do método de cadastro (ajustado conforme acima)
// ...


    
   
// Configuração de layout e adição de outros componentes
// ...

// Código do método de cadastro (ajustado conforme acima)
// ...

    public void PreencherTabelaFuncionario(){
       // chamando o produtos controller
        FuncionarioController dao = new FuncionarioController();
        // capturando a lista de produtos que vem do banco de dados
        List<Funcionario> lista = dao.listaFuncionario();
        
        // Obtendo o modelo da tabela
        DefaultTableModel modeloTabela = (DefaultTableModel) tabelaFuncionario.getModel();
    
        // Limpando a tabela antes de adicionar novos dados
        modeloTabela.setRowCount(0);
    
        // Verificando se a lista não é nula
        if (lista != null && !lista.isEmpty()) {
            // Jogando os dados para dentro da minha tabela
            for (Funcionario f : lista) {
                // Criando uma nova linha para a tabela
                Object[] linha = {
                f.getIdFuncionario(),
                f.getNomeFuncionario(),
                f.getNomeCargo(),
                f.getCpfFuncionario()
                };
                // Adicionando a linha ao modelo da tabela
                modeloTabela.addRow(linha);
            }
        } else {
            JOptionPane.showMessageDialog (this,"Nenhum Funcionario encontrado.");
        }
    }
    
    public void PreencherTabelaSala(){
       // chamando o produtos controller
        ChaveController dao = new ChaveController ();
        // capturando a lista de produtos que vem do banco de dados
        List<Chave> lista = dao.listaChave();
        
        // Obtendo o modelo da tabela
        DefaultTableModel modeloTabela = (DefaultTableModel) tabelaSala.getModel();
    
        // Limpando a tabela antes de adicionar novos dados
        modeloTabela.setRowCount(0);
    
        // Verificando se a lista não é nula
        if (lista != null && !lista.isEmpty()) {
            // Jogando os dados para dentro da minha tabela
            for (Chave c : lista) {
                // Criando uma nova linha para a tabela
                Object[] linha = {
                c.getIdChave(),
                c.getNomeSala(),
                };
                // Adicionando a linha ao modelo da tabela
                modeloTabela.addRow(linha);
            }
        } else {
            JOptionPane.showMessageDialog (this,"Nenhuma sala encontrado.");
        }
    }
    
     public void PreencherTabelaSelecao(){
       // chamando o produtos controller
        SelecaoController dao = new SelecaoController();
        // capturando a lista de produtos que vem do banco de dados
        List<Selecao> lista = dao.listaSelecao();
        
        // Obtendo o modelo da tabela
        DefaultTableModel modeloTabela = (DefaultTableModel) TabelaDeSelecao.getModel();
    
        // Limpando a tabela antes de adicionar novos dados
        modeloTabela.setRowCount(0);
    
        // Verificando se a lista não é nula
        if (lista != null && !lista.isEmpty()) {
            // Jogando os dados para dentro da minha tabela
            for (Selecao s : lista) {
                // Criando uma nova linha para a tabela
                Object[] linha = {
                s.getNomeFuncionario(),
                s.getNomeSala(),
                s.getPeriodo(),
                s.getCpfFuncionario(),
                s.getIdfuncionario(),
                s.getIdchave()
               
                };
                // Adicionando a linha ao modelo da tabela
                modeloTabela.addRow(linha);
            }
        } else {
            JOptionPane.showMessageDialog (this,"Nenhuma seleção encontrada.");
        }
    }
     
     
    public void limparCampoSelecao(){
        campoFuncionarioSelecao.setText("");
        campoSalaSelecao.setText("");
        setIdFuncionaroTabela(0);
        setIdSalaTabela(0);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        painelInicial = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        PainelcadastrosSalaFunc = new javax.swing.JPanel();
        idCha1 = new javax.swing.JTextField();
        idFun1 = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        campoNomeFuncCadastro = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        btnCadastrarFunc = new javax.swing.JButton();
        campoCpfCadastro = new javax.swing.JTextField();
        jlabel2 = new javax.swing.JLabel();
        campoCargo = new javax.swing.JTextField();
        campoNomeSalaCadastro = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        btnCadastrarSala = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        menuCooped = new javax.swing.JPanel();
        btnCadastrarFuncionario = new javax.swing.JToggleButton();
        btnSelecao = new javax.swing.JToggleButton();
        btnSelecoes = new javax.swing.JToggleButton();
        jPanel3 = new javax.swing.JPanel();
        btnReservasCoped = new javax.swing.JToggleButton();
        jLabel12 = new javax.swing.JLabel();
        painelSelecao = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        campoFuncionarioSelecao = new javax.swing.JTextField();
        campoSalaSelecao = new javax.swing.JTextField();
        cadastrarSelecao = new javax.swing.JButton();
        jScrollPane5 = new javax.swing.JScrollPane();
        tabelaSala = new javax.swing.JTable();
        jScrollPane6 = new javax.swing.JScrollPane();
        tabelaFuncionario = new javax.swing.JTable();
        jLabel23 = new javax.swing.JLabel();
        comboPeriodoSelecao = new javax.swing.JComboBox<>();
        jLabel22 = new javax.swing.JLabel();
        painelTodasSelecao = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TabelaDeSelecao = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        campoNomeFuncionario = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        bReservar = new javax.swing.JButton();
        campoNomeSala = new javax.swing.JTextField();
        panelTodasResevas = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        painelInicial.setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setBackground(new java.awt.Color(51, 153, 255));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 530, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 396, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout painelInicialLayout = new javax.swing.GroupLayout(painelInicial);
        painelInicial.setLayout(painelInicialLayout);
        painelInicialLayout.setHorizontalGroup(
            painelInicialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelInicialLayout.createSequentialGroup()
                .addGap(215, 215, 215)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(254, Short.MAX_VALUE))
        );
        painelInicialLayout.setVerticalGroup(
            painelInicialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelInicialLayout.createSequentialGroup()
                .addGap(103, 103, 103)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(221, Short.MAX_VALUE))
        );

        PainelcadastrosSalaFunc.setBackground(new java.awt.Color(255, 255, 255));

        idCha1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idCha1ActionPerformed(evt);
            }
        });

        idFun1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idFun1ActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(51, 153, 255));
        jLabel7.setText("Nome Funcionario:");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 153, 255));
        jLabel8.setText("CPF:");

        campoNomeFuncCadastro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoNomeFuncCadastroActionPerformed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 153, 255));
        jLabel9.setText("Nome de sala:");

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(51, 153, 255));
        jLabel10.setText("CADASTRAR FUNCIONARIO");

        btnCadastrarFunc.setBackground(new java.awt.Color(0, 153, 255));
        btnCadastrarFunc.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnCadastrarFunc.setForeground(new java.awt.Color(255, 255, 255));
        btnCadastrarFunc.setText("CADASTRAR FUNCIONARIO");
        btnCadastrarFunc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadastrarFuncActionPerformed(evt);
            }
        });

        campoCpfCadastro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoCpfCadastroActionPerformed(evt);
            }
        });

        jlabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jlabel2.setForeground(new java.awt.Color(0, 153, 255));
        jlabel2.setText("Cargo:");

        campoCargo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoCargoActionPerformed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 153, 255));
        jLabel11.setText("CADASTRAR SALA");

        btnCadastrarSala.setBackground(new java.awt.Color(0, 153, 255));
        btnCadastrarSala.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnCadastrarSala.setForeground(new java.awt.Color(255, 255, 255));
        btnCadastrarSala.setText("CADASTRAR SALAS");
        btnCadastrarSala.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadastrarSalaActionPerformed(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(51, 153, 255));
        jLabel13.setText("CADASTROS");

        jLabel1.setFont(new java.awt.Font("Yu Gothic UI Light", 0, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 51, 51));
        jLabel1.setText("11 digitos(BD)");

        javax.swing.GroupLayout PainelcadastrosSalaFuncLayout = new javax.swing.GroupLayout(PainelcadastrosSalaFunc);
        PainelcadastrosSalaFunc.setLayout(PainelcadastrosSalaFuncLayout);
        PainelcadastrosSalaFuncLayout.setHorizontalGroup(
            PainelcadastrosSalaFuncLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PainelcadastrosSalaFuncLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(PainelcadastrosSalaFuncLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PainelcadastrosSalaFuncLayout.createSequentialGroup()
                        .addComponent(idCha1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(56, 56, 56))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PainelcadastrosSalaFuncLayout.createSequentialGroup()
                        .addComponent(idFun1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18))))
            .addGroup(PainelcadastrosSalaFuncLayout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(PainelcadastrosSalaFuncLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PainelcadastrosSalaFuncLayout.createSequentialGroup()
                        .addGroup(PainelcadastrosSalaFuncLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10)
                            .addComponent(jLabel7)
                            .addComponent(campoNomeFuncCadastro, javax.swing.GroupLayout.PREFERRED_SIZE, 251, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8)
                            .addComponent(jlabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(campoCargo, javax.swing.GroupLayout.PREFERRED_SIZE, 251, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnCadastrarFunc, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 204, Short.MAX_VALUE)
                        .addGroup(PainelcadastrosSalaFuncLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9)
                            .addComponent(campoNomeSalaCadastro, javax.swing.GroupLayout.PREFERRED_SIZE, 247, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 296, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnCadastrarSala, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(154, 154, 154))
                    .addGroup(PainelcadastrosSalaFuncLayout.createSequentialGroup()
                        .addGroup(PainelcadastrosSalaFuncLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel13)
                            .addGroup(PainelcadastrosSalaFuncLayout.createSequentialGroup()
                                .addComponent(campoCpfCadastro, javax.swing.GroupLayout.PREFERRED_SIZE, 251, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        PainelcadastrosSalaFuncLayout.setVerticalGroup(
            PainelcadastrosSalaFuncLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PainelcadastrosSalaFuncLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel13)
                .addGap(72, 72, 72)
                .addGroup(PainelcadastrosSalaFuncLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(idFun1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(idCha1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(76, 76, 76)
                .addGroup(PainelcadastrosSalaFuncLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PainelcadastrosSalaFuncLayout.createSequentialGroup()
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel9)
                        .addGap(0, 0, 0)
                        .addComponent(campoNomeSalaCadastro, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnCadastrarSala, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(PainelcadastrosSalaFuncLayout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel7)
                        .addGap(0, 0, 0)
                        .addComponent(campoNomeFuncCadastro, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jlabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(campoCargo, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(PainelcadastrosSalaFuncLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(campoCpfCadastro, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))))
                .addGap(18, 18, 18)
                .addComponent(btnCadastrarFunc, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(219, Short.MAX_VALUE))
        );

        menuCooped.setBackground(new java.awt.Color(51, 153, 255));

        btnCadastrarFuncionario.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnCadastrarFuncionario.setForeground(new java.awt.Color(51, 153, 255));
        btnCadastrarFuncionario.setText("Cadastrar Funcionario");
        btnCadastrarFuncionario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadastrarFuncionarioActionPerformed(evt);
            }
        });

        btnSelecao.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnSelecao.setForeground(new java.awt.Color(51, 153, 255));
        btnSelecao.setText("Definir Seleção");
        btnSelecao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSelecaoActionPerformed(evt);
            }
        });

        btnSelecoes.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnSelecoes.setForeground(new java.awt.Color(51, 153, 255));
        btnSelecoes.setText("Seleções");
        btnSelecoes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSelecoesActionPerformed(evt);
            }
        });

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 198, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 172, Short.MAX_VALUE)
        );

        btnReservasCoped.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnReservasCoped.setForeground(new java.awt.Color(51, 153, 255));
        btnReservasCoped.setText("Reservas cadastradas");
        btnReservasCoped.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReservasCopedActionPerformed(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("COPED");

        javax.swing.GroupLayout menuCoopedLayout = new javax.swing.GroupLayout(menuCooped);
        menuCooped.setLayout(menuCoopedLayout);
        menuCoopedLayout.setHorizontalGroup(
            menuCoopedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(btnSelecao, javax.swing.GroupLayout.DEFAULT_SIZE, 263, Short.MAX_VALUE)
            .addComponent(btnCadastrarFuncionario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnSelecoes, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnReservasCoped, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, menuCoopedLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32))
            .addGroup(menuCoopedLayout.createSequentialGroup()
                .addGap(92, 92, 92)
                .addComponent(jLabel12)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        menuCoopedLayout.setVerticalGroup(
            menuCoopedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuCoopedLayout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel12)
                .addGap(10, 10, 10)
                .addComponent(btnCadastrarFuncionario, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnSelecao, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnSelecoes, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnReservasCoped, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(48, Short.MAX_VALUE))
        );

        painelSelecao.setBackground(new java.awt.Color(255, 255, 255));

        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(0, 153, 255));
        jLabel19.setText("SELECIONE UM FUNCIONARIO:");

        jLabel20.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(0, 153, 255));
        jLabel20.setText("Nome do Funcionario:");

        jLabel21.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(0, 153, 255));
        jLabel21.setText("Sala:");

        campoFuncionarioSelecao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoFuncionarioSelecaoActionPerformed(evt);
            }
        });

        campoSalaSelecao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoSalaSelecaoActionPerformed(evt);
            }
        });

        cadastrarSelecao.setBackground(new java.awt.Color(0, 153, 255));
        cadastrarSelecao.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        cadastrarSelecao.setForeground(new java.awt.Color(255, 255, 255));
        cadastrarSelecao.setText("Cadastrar");
        cadastrarSelecao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cadastrarSelecaoActionPerformed(evt);
            }
        });

        tabelaSala.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Id", "Nome da sala"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tabelaSala.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                selecionarSalaDaTabela(evt);
            }
        });
        jScrollPane5.setViewportView(tabelaSala);
        if (tabelaSala.getColumnModel().getColumnCount() > 0) {
            tabelaSala.getColumnModel().getColumn(0).setMinWidth(50);
            tabelaSala.getColumnModel().getColumn(0).setPreferredWidth(50);
            tabelaSala.getColumnModel().getColumn(0).setMaxWidth(50);
        }

        tabelaFuncionario.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Id", "Nome Funcionario", "Cargo", "Cpf"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tabelaFuncionario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                selecionarFuncionarioDaTabela(evt);
            }
        });
        jScrollPane6.setViewportView(tabelaFuncionario);
        if (tabelaFuncionario.getColumnModel().getColumnCount() > 0) {
            tabelaFuncionario.getColumnModel().getColumn(0).setMinWidth(50);
            tabelaFuncionario.getColumnModel().getColumn(0).setPreferredWidth(50);
            tabelaFuncionario.getColumnModel().getColumn(0).setMaxWidth(50);
        }

        jLabel23.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(0, 153, 255));
        jLabel23.setText("SELECIONE A SALA:");

        comboPeriodoSelecao.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "MATUTINO", "VESPERTINO", "NOTURNO" }));

        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(0, 153, 255));
        jLabel22.setText("Periodo:");

        javax.swing.GroupLayout painelSelecaoLayout = new javax.swing.GroupLayout(painelSelecao);
        painelSelecao.setLayout(painelSelecaoLayout);
        painelSelecaoLayout.setHorizontalGroup(
            painelSelecaoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, painelSelecaoLayout.createSequentialGroup()
                .addContainerGap(41, Short.MAX_VALUE)
                .addGroup(painelSelecaoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(painelSelecaoLayout.createSequentialGroup()
                        .addGroup(painelSelecaoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(comboPeriodoSelecao, javax.swing.GroupLayout.Alignment.LEADING, 0, 199, Short.MAX_VALUE)
                            .addComponent(jLabel22, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 300, Short.MAX_VALUE)
                        .addGroup(painelSelecaoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(painelSelecaoLayout.createSequentialGroup()
                                .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(campoSalaSelecao, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(painelSelecaoLayout.createSequentialGroup()
                                .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(campoFuncionarioSelecao, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(painelSelecaoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(cadastrarSelecao, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(painelSelecaoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 933, Short.MAX_VALUE)
                            .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 369, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 369, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane6))))
                .addGap(26, 26, 26))
        );
        painelSelecaoLayout.setVerticalGroup(
            painelSelecaoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelSelecaoLayout.createSequentialGroup()
                .addContainerGap(28, Short.MAX_VALUE)
                .addComponent(jLabel19)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel23)
                .addGap(18, 18, 18)
                .addGroup(painelSelecaoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(painelSelecaoLayout.createSequentialGroup()
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addComponent(jLabel22)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(comboPeriodoSelecao, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelSelecaoLayout.createSequentialGroup()
                        .addGroup(painelSelecaoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(campoFuncionarioSelecao, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel20))
                        .addGap(18, 18, 18)
                        .addGroup(painelSelecaoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel21)
                            .addComponent(campoSalaSelecao, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(26, 26, 26)
                .addComponent(cadastrarSelecao, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8))
        );

        painelTodasSelecao.setBackground(new java.awt.Color(255, 255, 255));

        TabelaDeSelecao.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Nome Funcionario", "Sala ", "Periodo", "Cpf", "id Fun", "id Cha"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TabelaDeSelecao.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TabelaDeSelecaotabelaSelecaoClick(evt);
            }
        });
        jScrollPane1.setViewportView(TabelaDeSelecao);
        if (TabelaDeSelecao.getColumnModel().getColumnCount() > 0) {
            TabelaDeSelecao.getColumnModel().getColumn(4).setMinWidth(0);
            TabelaDeSelecao.getColumnModel().getColumn(4).setPreferredWidth(0);
            TabelaDeSelecao.getColumnModel().getColumn(4).setMaxWidth(0);
            TabelaDeSelecao.getColumnModel().getColumn(5).setPreferredWidth(0);
            TabelaDeSelecao.getColumnModel().getColumn(5).setMaxWidth(0);
        }

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(51, 153, 255));
        jLabel2.setText("Nome Funcionario:");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(51, 153, 255));
        jLabel3.setText("Nome de sala:");

        campoNomeFuncionario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoNomeFuncionarioActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(51, 153, 255));
        jLabel6.setText("SELEÇÕES DO MÊS");

        bReservar.setBackground(new java.awt.Color(0, 153, 255));
        bReservar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        bReservar.setForeground(new java.awt.Color(255, 255, 255));
        bReservar.setText("EXCLUIR SELEÇÃO");
        bReservar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bReservarActionPerformed(evt);
            }
        });

        campoNomeSala.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoNomeSalaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout painelTodasSelecaoLayout = new javax.swing.GroupLayout(painelTodasSelecao);
        painelTodasSelecao.setLayout(painelTodasSelecaoLayout);
        painelTodasSelecaoLayout.setHorizontalGroup(
            painelTodasSelecaoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelTodasSelecaoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(painelTodasSelecaoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(painelTodasSelecaoLayout.createSequentialGroup()
                        .addGroup(painelTodasSelecaoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addGroup(painelTodasSelecaoLayout.createSequentialGroup()
                                .addGroup(painelTodasSelecaoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addComponent(campoNomeFuncionario, javax.swing.GroupLayout.PREFERRED_SIZE, 251, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(campoNomeSala, javax.swing.GroupLayout.PREFERRED_SIZE, 251, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, painelTodasSelecaoLayout.createSequentialGroup()
                                        .addComponent(jLabel2)
                                        .addGap(90, 90, 90)))
                                .addGap(63, 63, 63)
                                .addComponent(bReservar, javax.swing.GroupLayout.PREFERRED_SIZE, 244, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 430, Short.MAX_VALUE)))
                .addContainerGap())
        );
        painelTodasSelecaoLayout.setVerticalGroup(
            painelTodasSelecaoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelTodasSelecaoLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel6)
                .addGap(24, 24, 24)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 476, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(painelTodasSelecaoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(bReservar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, painelTodasSelecaoLayout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(0, 0, 0)
                        .addComponent(campoNomeFuncionario, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(campoNomeSala, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(34, Short.MAX_VALUE))
        );

        panelTodasResevas.setBackground(new java.awt.Color(51, 204, 0));

        javax.swing.GroupLayout panelTodasResevasLayout = new javax.swing.GroupLayout(panelTodasResevas);
        panelTodasResevas.setLayout(panelTodasResevasLayout);
        panelTodasResevasLayout.setHorizontalGroup(
            panelTodasResevasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1000, Short.MAX_VALUE)
        );
        panelTodasResevasLayout.setVerticalGroup(
            panelTodasResevasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 720, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(menuCooped, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1010, Short.MAX_VALUE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap(267, Short.MAX_VALUE)
                    .addComponent(PainelcadastrosSalaFunc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap(267, Short.MAX_VALUE)
                    .addComponent(painelSelecao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap(267, Short.MAX_VALUE)
                    .addComponent(painelTodasSelecao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap(268, Short.MAX_VALUE)
                    .addComponent(painelInicial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap(267, Short.MAX_VALUE)
                    .addComponent(panelTodasResevas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(menuCooped, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(PainelcadastrosSalaFunc, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(painelSelecao, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(painelTodasSelecao, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(painelInicial, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(panelTodasResevas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCadastrarFuncionarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastrarFuncionarioActionPerformed
       painelSelecao.setVisible(false);
       PainelcadastrosSalaFunc.setVisible(true);
       painelTodasSelecao.setVisible(false);
       painelInicial.setVisible(false);
       
    }//GEN-LAST:event_btnCadastrarFuncionarioActionPerformed

    private void btnSelecaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSelecaoActionPerformed
        PainelcadastrosSalaFunc.setVisible(false);
        painelSelecao.setVisible(true);
        painelTodasSelecao.setVisible(false);
        painelInicial.setVisible(false);
        PreencherTabelaFuncionario();
        PreencherTabelaSala();
    }//GEN-LAST:event_btnSelecaoActionPerformed

    private void btnSelecoesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSelecoesActionPerformed
        painelTodasSelecao.setVisible(true);
        PainelcadastrosSalaFunc.setVisible(false);
        painelSelecao.setVisible(false);
        painelInicial.setVisible(false);
        PreencherTabelaSelecao();
    }//GEN-LAST:event_btnSelecoesActionPerformed

    private void idCha1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idCha1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_idCha1ActionPerformed

    private void idFun1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idFun1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_idFun1ActionPerformed

    private void campoNomeFuncCadastroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoNomeFuncCadastroActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_campoNomeFuncCadastroActionPerformed

    private void campoCpfCadastroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoCpfCadastroActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_campoCpfCadastroActionPerformed

 
    
    private void btnCadastrarFuncActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastrarFuncActionPerformed
  // Obter os dados do formulário
String nome = campoNomeFuncCadastro.getText().trim(); // Remover espaços extras no início e no fim
String cargo = campoCargo.getText().trim();
String cpf = campoCpfCadastro.getText().trim(); // Remover todos os caracteres não numéricos (pontos, traços)

// Exibir valores dos campos para debug
System.out.println("Nome: " + nome);
System.out.println("Cargo: " + cargo);
System.out.println("CPF: " + cpf);

// Verificar se todos os campos estão preenchidos
if (!nome.isEmpty() && !cargo.isEmpty() && !cpf.isEmpty()) {
    // Verificar se o CPF tem exatamente 11 caracteres numéricos
    if (cpf.length() == 11) {
        try {
            // Cadastro
            Funcionario f = new Funcionario(nome, cargo, cpf);
            FuncionarioController dao = new FuncionarioController();
            boolean cadastrou = dao.insert(f);

            if (cadastrou) {
                // Mensagem de sucesso
                JOptionPane.showMessageDialog(this, "Cadastro realizado com sucesso!");
                limparCampoCadastroFunc();
                System.err.println("Cadastrado!");
            } else {
                // Mensagem de erro
                JOptionPane.showMessageDialog(this, "Erro ao cadastrar");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    } else {
        // Mensagem de erro se o CPF não tiver 11 caracteres numéricos
        JOptionPane.showMessageDialog(this, "CPF inválido. Deve ter exatamente 11 caracteres numéricos.");
    }
} else {
    // Mensagem de erro se algum campo estiver vazio
    JOptionPane.showMessageDialog(this, "Preencha todos os campos do funcionário corretamente.");
}



    }//GEN-LAST:event_btnCadastrarFuncActionPerformed

    private void campoCargoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoCargoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_campoCargoActionPerformed

    private void btnCadastrarSalaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastrarSalaActionPerformed
        String sala = campoNomeSalaCadastro.getText();
        
        ChaveController dao = new ChaveController();
        List<Chave> listaChave = dao.listaChave();
        
        // Verifica se a sala é válida
        if (!sala.isEmpty() && sala.length() >= 3) {
            if (listaChave != null) {
                for (Chave c : listaChave) {
                    if (sala.equalsIgnoreCase(c.getNomeSala())) {
                        JOptionPane.showMessageDialog(null, "Sala já cadastrada");
                        return; 
                    }
                }
            }

            // Cria e insere a nova chave
            Chave chaveCadastrar = new Chave(sala, true);
            boolean sucesso = dao.inserirChave(chaveCadastrar); // Corrigido o nome do método
            if (sucesso) {
               JOptionPane.showMessageDialog(this, "Sala cadastrada com sucesso!");
            } else {
                JOptionPane.showMessageDialog(null, "Não foi possível cadastrar a sala!");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Preencha o nome da sala corretamente!");
        }
    }//GEN-LAST:event_btnCadastrarSalaActionPerformed

    private void cadastrarSelecaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cadastrarSelecaoActionPerformed
         String periodo = (String) comboPeriodoSelecao.getSelectedItem();
        if(getIdFuncionaroTabela() == 0 || getIdSalaTabela() == 0){
            JOptionPane.showMessageDialog(this, "Selecione funcionario e sala nas tabelas!", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }else{
            
            Selecao s = new Selecao();
            s.setIdfuncionario(getIdFuncionaroTabela());
            s.setIdchave(getIdSalaTabela());
            s.setNomeFuncionario(nomeFuncionarioTabela);
            s.setNomeSala(nomeSalaTabela);
            s.setPeriodo(periodo);

            SelecaoController dao = new SelecaoController();
            
            List<Selecao> listaSelecao = dao.listaSelecao();
            for (Selecao se : listaSelecao) {
                if(s.getIdfuncionario() == se.getIdfuncionario() && s.getIdchave() == se.getIdchave() && s.getPeriodo().equals(se.getPeriodo())){
                    JOptionPane.showMessageDialog(this, "Seleção ja cadastrada!", "Erro", JOptionPane.ERROR_MESSAGE);
                    return;
                } else if(s.getIdchave() == se.getIdchave() && s.getPeriodo().equals(se.getPeriodo())){
                    JOptionPane.showMessageDialog(this, "Esta sala está selecionada para outro funcionario nesse periodo!", "Erro", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }             

            try {
                boolean adicionarSelecao = dao.adicionarSelecao(s);
                if (adicionarSelecao) {
                    JOptionPane.showMessageDialog(this, "Seleção realizada com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                }else {
                    JOptionPane.showMessageDialog(this, "Não foi possível adicionar seleção!", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Erro ao realizar a seleção: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_cadastrarSelecaoActionPerformed

    private int idFuncionaroTabela;
    private String nomeFuncionarioTabela;
    private void selecionarFuncionarioDaTabela(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_selecionarFuncionarioDaTabela
          // capturar a linha que o usuario clicou
        int linhaselecionada = tabelaFuncionario.getSelectedRow();
        // verificar se o usuario clicou em alguma linha
        if (linhaselecionada>=0){
          // definir modelo padrão da tabela
          DefaultTableModel modelotabela = (DefaultTableModel) tabelaFuncionario.getModel();
          this.idFuncionaroTabela = Integer.parseInt(modelotabela.getValueAt(linhaselecionada,0).toString());
          this.nomeFuncionarioTabela = modelotabela.getValueAt(linhaselecionada,1).toString();
          String funcionario = modelotabela.getValueAt(linhaselecionada, 0).toString();
          campoFuncionarioSelecao.setText(nomeFuncionarioTabela);
        }
    }//GEN-LAST:event_selecionarFuncionarioDaTabela

    private int idSalaTabela;
    private String nomeSalaTabela;

    public int getIdFuncionaroTabela() {
        return idFuncionaroTabela;
    }

    public void setIdFuncionaroTabela(int idFuncionaroTabela) {
        this.idFuncionaroTabela = idFuncionaroTabela;
    }

    public int getIdSalaTabela() {
        return idSalaTabela;
    }

    public void setIdSalaTabela(int idSalaTabela) {
        this.idSalaTabela = idSalaTabela;
    }
    private void selecionarSalaDaTabela(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_selecionarSalaDaTabela
         // capturar a linha que o usuario clicou
        int linhaselecionada = tabelaSala.getSelectedRow();
        // verificar se o usuario clicou em alguma linha
        if (linhaselecionada>=0){
          // definir modelo padrão da tabela
          DefaultTableModel modelotabela = (DefaultTableModel) tabelaSala.getModel();
          this.idSalaTabela = Integer.parseInt(modelotabela.getValueAt(linhaselecionada,0).toString());
          this.nomeSalaTabela = modelotabela.getValueAt(linhaselecionada,1).toString();
          campoSalaSelecao.setText(nomeSalaTabela);
        }
    }//GEN-LAST:event_selecionarSalaDaTabela

    private void campoSalaSelecaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoSalaSelecaoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_campoSalaSelecaoActionPerformed

    private void campoFuncionarioSelecaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoFuncionarioSelecaoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_campoFuncionarioSelecaoActionPerformed

    private void btnReservasCopedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReservasCopedActionPerformed
        panelTodasResevas.setVisible(true);
        painelTodasSelecao.setVisible(false);
        PainelcadastrosSalaFunc.setVisible(false);
        painelSelecao.setVisible(false);
        painelInicial.setVisible(false);
    }//GEN-LAST:event_btnReservasCopedActionPerformed

    private int idFuncionario;
    private int idChave;
    private void TabelaDeSelecaotabelaSelecaoClick(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TabelaDeSelecaotabelaSelecaoClick
        // TODO add your handling code here:
        // capturar a linha que o usuario clicou
        int linhaselecionada = TabelaDeSelecao.getSelectedRow();
        // verificar se o usuario clicou em alguma linha
        if (linhaselecionada>=0){
            // definir modelo padrão da tabela
            DefaultTableModel modelotabela = (DefaultTableModel) TabelaDeSelecao.getModel();
            this.idFuncionario = Integer.parseInt(modelotabela.getValueAt(linhaselecionada,4).toString());
            this.idChave = Integer.parseInt(modelotabela.getValueAt(linhaselecionada, 5).toString());
            String funcionario = modelotabela.getValueAt(linhaselecionada, 0).toString();
            String sala = modelotabela.getValueAt(linhaselecionada, 1).toString();
            //String periodo = modelotabela.getValueAt(linhaselecionada, 1).toString();
            campoNomeFuncionario.setText(funcionario);
            campoNomeSala.setText(sala);
            System.err.println(idFuncionario);
        }// fim do if
    }//GEN-LAST:event_TabelaDeSelecaotabelaSelecaoClick

    private void campoNomeFuncionarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoNomeFuncionarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_campoNomeFuncionarioActionPerformed

    private void bReservarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bReservarActionPerformed
        // TODO add your handling code here:
          // Obter a linha selecionada na tabela
    int linhaselecionada = TabelaDeSelecao.getSelectedRow(); 
    
    // Verificar se há uma linha selecionada
    if (linhaselecionada >= 0) { 
        // Obter o modelo da tabela
        DefaultTableModel modelotabela = (DefaultTableModel) TabelaDeSelecao.getModel(); 
        
        // Extrair os valores de idFuncionario e idChave
        int idFuncionario = Integer.parseInt(modelotabela.getValueAt(linhaselecionada, 4).toString()); 
        int idChave = Integer.parseInt(modelotabela.getValueAt(linhaselecionada, 5).toString()); 
        
        // Criar o controlador para excluir a seleção
        SelecaoController controller = new SelecaoController(); 
        
        // Chamar o método para excluir a seleção
        boolean sucesso = controller.excluirSelecao(idFuncionario, idChave); 
        
        // Verificar se a exclusão foi bem-sucedida
        if (sucesso) { 
            JOptionPane.showMessageDialog(this, "Seleção excluída com sucesso!"); 
            PreencherTabelaSelecao(); // Atualiza a tabela
        } else { 
            JOptionPane.showMessageDialog(this, "Erro ao excluir a seleção.");
        } 
    } else { 
        // Caso nenhuma linha tenha sido selecionada
        JOptionPane.showMessageDialog(this, "Selecione uma linha para excluir."); 
    } 
    }//GEN-LAST:event_bReservarActionPerformed

    private void campoNomeSalaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoNomeSalaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_campoNomeSalaActionPerformed

    
       
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MenuCooped.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MenuCooped.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MenuCooped.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MenuCooped.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MenuCooped().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel PainelcadastrosSalaFunc;
    private javax.swing.JTable TabelaDeSelecao;
    private javax.swing.JButton bReservar;
    private javax.swing.JButton btnCadastrarFunc;
    private javax.swing.JToggleButton btnCadastrarFuncionario;
    private javax.swing.JButton btnCadastrarSala;
    private javax.swing.JToggleButton btnReservasCoped;
    private javax.swing.JToggleButton btnSelecao;
    private javax.swing.JToggleButton btnSelecoes;
    private javax.swing.JButton cadastrarSelecao;
    private javax.swing.JTextField campoCargo;
    private javax.swing.JTextField campoCpfCadastro;
    private javax.swing.JTextField campoFuncionarioSelecao;
    private javax.swing.JTextField campoNomeFuncCadastro;
    private javax.swing.JTextField campoNomeFuncionario;
    private javax.swing.JTextField campoNomeSala;
    private javax.swing.JTextField campoNomeSalaCadastro;
    private javax.swing.JTextField campoSalaSelecao;
    private javax.swing.JComboBox<String> comboPeriodoSelecao;
    private javax.swing.JTextField idCha1;
    private javax.swing.JTextField idFun1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JLabel jlabel2;
    private javax.swing.JPanel menuCooped;
    private javax.swing.JPanel painelInicial;
    private javax.swing.JPanel painelSelecao;
    private javax.swing.JPanel painelTodasSelecao;
    private javax.swing.JPanel panelTodasResevas;
    private javax.swing.JTable tabelaFuncionario;
    private javax.swing.JTable tabelaSala;
    // End of variables declaration//GEN-END:variables
}
