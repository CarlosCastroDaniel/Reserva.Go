/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package View;

import Controller.Conexao;
import Controller.FuncionarioController;
import Controller.ReservaController;
import Controller.SelecaoController;
import MODEL.Funcionario;
import MODEL.Reserva;
import Model.ReservaDetalhes;
import Model.Selecao;
import static java.awt.SystemColor.menu;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author UFNT
 */
public class Menu extends javax.swing.JFrame {

    /**
     * Creates new form Menu
     */
    public Menu() {
        
        setTitle("Porteiro");
        setSize(900, 700); // Define o tamanho da janela
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false); // Impede redimensionamento da janela
        
        initComponents();
        
          // Centraliza a janela no centro da tela
        setLocationRelativeTo(null);

        // Torna a janela visível
        setVisible(true);
        panelMenu.setVisible(true);
        panelReservasT.setVisible(false);
        panelCadastroDeReservas.setVisible(false);
        panelDevolucao.setVisible(false);
        campoNomeFuncionarioReserva.setEditable(false);
        campoNomeSalaReserva.setEditable(false);
        campoFuncionarioDevolucao.setEditable(false);
        campoSalaDevolucao.setEditable(false);
       
    }
    
    private void listarReservasNoPainel() { 
    // Implemente a lógica para listar as reservas no painel `panelReservasT`
    
    // Exemplo simplificado para adicionar uma tabela ao painel
    String[] colunas = {"ID do Funcionário", "Nome do Funcionário", "Nome da Sala", 
                        "Disponibilidade", "Hora da Reserva", "Hora da Entrega", "Entregue"};
    
    DefaultTableModel modeloTabela = new DefaultTableModel(colunas, 0); 
    
    try { 
        // Criar o controlador para acessar os dados das reservas
        ReservaController reservaController = new ReservaController(); 
        
        // Obter os dados das reservas
        List<Object[]> dadosReservas = reservaController.getDadosReservas(); 
        
        // Adicionar as linhas à tabela
        for (Object[] linha : dadosReservas) { 
            modeloTabela.addRow(linha); 
        } 
        
        // Criar a tabela com o modelo de dados
        JTable tabelaReservas = new JTable(modeloTabela); 
        
        // Criar um JScrollPane para adicionar a tabela
        JScrollPane scrollPane = new JScrollPane(tabelaReservas); 
        
        // Adicione a tabela ao painel `panelReservasT`
        panelReservasT.removeAll(); // Remove componentes anteriores, se houver
        panelReservasT.add(scrollPane); 
        
        // Atualiza e repinta o painel
        panelReservasT.revalidate(); // Atualiza o painel
        panelReservasT.repaint(); // Repinta o painel 
    } catch (SQLException e) { 
        e.printStackTrace(); 
        JOptionPane.showMessageDialog(this, "Erro ao listar reservas: " + e.getMessage()); 
    } 
}


    private void atualizarTabelaReservas() { 
    try { 
        // Criar o controlador para acessar os dados das reservas
        ReservaController reservaController = new ReservaController(); 
        
        // Obter os dados das reservas
        List<Object[]> dadosReservas = reservaController.getDadosReservas(); 
        
        // Obter o modelo da tabela
        DefaultTableModel model = (DefaultTableModel) tabelaReservaInfo.getModel(); 
        
        // Limpar a tabela antes de adicionar novos dados
        model.setRowCount(0); 
        
        // Adicionar cada linha de dados à tabela
        for (Object[] linha : dadosReservas) { 
            model.addRow(linha); 
        } 
    } catch (SQLException e) { 
        // Tratar exceção de SQL
        e.printStackTrace(); 
        
        // Exibir mensagem de erro
        JOptionPane.showMessageDialog(this, "Erro ao atualizar a tabela: " + e.getMessage()); 
    } 
}

    public void listarReservas() { 
    try { 
        // Criar o controlador para acessar os dados das reservas
        ReservaController reservaController = new ReservaController(); 
        
        // Obter os dados das reservas
        List<Object[]> dadosReservas = reservaController.getDadosReservas(); 
        
        // Obter o modelo da tabela
        DefaultTableModel modeloTabela = (DefaultTableModel) tabelaReservaInfo.getModel(); 
        
        // Limpar a tabela antes de adicionar novos dados
        modeloTabela.setRowCount(0); 
        
        // Adicionar cada linha de dados à tabela
        for (Object[] linha : dadosReservas) { 
            modeloTabela.addRow(linha); 
        } 
    } catch (SQLException e) { 
        e.printStackTrace(); 
        JOptionPane.showMessageDialog(this, "Erro ao atualizar a tabela: " + e.getMessage()); 
    } 
}


        // aqui pegamos os dados do controller e jogamos na nossa tabela
    public void PreencherTabelaSelecao(){
       // chamando o produtos controller
        SelecaoController dao = new SelecaoController();
        // capturando a lista de produtos que vem do banco de dados
        List<Selecao> lista = dao.listaSelecao();
        
        // Obtendo o modelo da tabela
        DefaultTableModel modeloTabela = (DefaultTableModel) TabelaDeSelecao.getModel();
    
        // Limpando a tabela antes de adicionar novos dados
        modeloTabela.setRowCount(0);
    
        // Verificando se a lista não é nula
        if (lista != null && !lista.isEmpty()) {
            // Jogando os dados para dentro da minha tabela
            for (Selecao s : lista) {
                // Criando uma nova linha para a tabela
                Object[] linha = {
                s.getNomeFuncionario(),
                s.getNomeSala(),
                s.getPeriodo(),
                s.getCpfFuncionario(),
                s.getIdfuncionario(),
                s.getIdchave()
               
                };
                // Adicionando a linha ao modelo da tabela
                modeloTabela.addRow(linha);
            }
        } else {
            JOptionPane.showMessageDialog (this,"Nenhuma seleção encontrada.");
        }
    }
    
    public void PreencherTabelaDevolucao(){
       // chamando o produtos controller
        ReservaController dao = new  ReservaController();
        // capturando a lista de produtos que vem do banco de dados
        List<ReservaDetalhes> lista = dao.listaReservaDetalhesNaoEntregue();
        
        // Obtendo o modelo da tabela
        DefaultTableModel modeloTabela = (DefaultTableModel) tabelaDevolucao.getModel();
    
        // Limpando a tabela antes de adicionar novos dados
        modeloTabela.setRowCount(0);
    
        // Verificando se a lista não é nula
        if (lista != null && !lista.isEmpty()) {
            // Jogando os dados para dentro da minha tabela
            for (ReservaDetalhes r : lista) {
                // Criando uma nova linha para a tabela
                Object[] linha = {
                r.getIdReserva(),
                r.getNomeFuncionario(),
                r.getNomeSala(),
                r.getDataDeReserva(),
                r.getHoraReserva(),
                r.isEntregue()
                };
                // Adicionando a linha ao modelo da tabela
                modeloTabela.addRow(linha);
            }
        } else {
            JOptionPane.showMessageDialog (this,"Nenhuma reserva cadastrada!");
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelMenu = new javax.swing.JPanel();
        BtnCadastrarReserva = new javax.swing.JToggleButton();
        BtnDevolucao = new javax.swing.JToggleButton();
        BtnTodasResevas = new javax.swing.JToggleButton();
        jPanel3 = new javax.swing.JPanel();
        iconUsuario = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        panelCadastroDeReservas = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TabelaDeSelecao = new javax.swing.JTable();
        pesquisaSala = new javax.swing.JTextField();
        idCha = new javax.swing.JTextField();
        idFun = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        campoNomeFuncionarioReserva = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        cadastrarReservarDoDia = new javax.swing.JButton();
        campoNomeSalaReserva = new javax.swing.JTextField();
        pesquisar = new javax.swing.JButton();
        panelDevolucao = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        campoFuncionarioDevolucao = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        campoSalaDevolucao = new javax.swing.JTextField();
        devolverChave = new javax.swing.JButton();
        jScrollPane5 = new javax.swing.JScrollPane();
        tabelaDevolucao = new javax.swing.JTable();
        panelReservasT = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabelaReservaInfo = new javax.swing.JTable();
        reservasFeitas = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        panelMenu.setBackground(new java.awt.Color(51, 153, 255));

        BtnCadastrarReserva.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        BtnCadastrarReserva.setForeground(new java.awt.Color(51, 153, 255));
        BtnCadastrarReserva.setText("Cadastrar Reservas");
        BtnCadastrarReserva.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnCadastrarReservaActionPerformed(evt);
            }
        });

        BtnDevolucao.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        BtnDevolucao.setForeground(new java.awt.Color(51, 153, 255));
        BtnDevolucao.setText("Devoluções");
        BtnDevolucao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnDevolucaoActionPerformed(evt);
            }
        });

        BtnTodasResevas.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        BtnTodasResevas.setForeground(new java.awt.Color(51, 153, 255));
        BtnTodasResevas.setText("Todas as Reservas");
        BtnTodasResevas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnTodasResevasActionPerformed(evt);
            }
        });

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(iconUsuario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(iconUsuario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("PORTEIRO");

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 114, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 111, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout panelMenuLayout = new javax.swing.GroupLayout(panelMenu);
        panelMenu.setLayout(panelMenuLayout);
        panelMenuLayout.setHorizontalGroup(
            panelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(BtnDevolucao, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(BtnCadastrarReserva, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(BtnTodasResevas, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelMenuLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(panelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel12)
                    .addGroup(panelMenuLayout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(33, 33, 33))
        );
        panelMenuLayout.setVerticalGroup(
            panelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMenuLayout.createSequentialGroup()
                .addGroup(panelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelMenuLayout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelMenuLayout.createSequentialGroup()
                        .addContainerGap(35, Short.MAX_VALUE)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                .addComponent(jLabel12)
                .addGap(35, 35, 35)
                .addComponent(BtnCadastrarReserva, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(BtnDevolucao, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(BtnTodasResevas, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(163, 163, 163))
        );

        panelCadastroDeReservas.setBackground(new java.awt.Color(255, 255, 255));

        TabelaDeSelecao.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Nome Funcionario", "Sala ", "Periodo", "Cpf", "id Fun", "id Cha"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TabelaDeSelecao.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabelaSelecaoClick(evt);
            }
        });
        jScrollPane1.setViewportView(TabelaDeSelecao);
        if (TabelaDeSelecao.getColumnModel().getColumnCount() > 0) {
            TabelaDeSelecao.getColumnModel().getColumn(0).setResizable(false);
            TabelaDeSelecao.getColumnModel().getColumn(1).setResizable(false);
            TabelaDeSelecao.getColumnModel().getColumn(2).setResizable(false);
            TabelaDeSelecao.getColumnModel().getColumn(3).setResizable(false);
            TabelaDeSelecao.getColumnModel().getColumn(4).setMinWidth(0);
            TabelaDeSelecao.getColumnModel().getColumn(4).setPreferredWidth(0);
            TabelaDeSelecao.getColumnModel().getColumn(4).setMaxWidth(0);
            TabelaDeSelecao.getColumnModel().getColumn(5).setMinWidth(0);
            TabelaDeSelecao.getColumnModel().getColumn(5).setPreferredWidth(0);
            TabelaDeSelecao.getColumnModel().getColumn(5).setMaxWidth(0);
        }

        pesquisaSala.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pesquisaSalaActionPerformed(evt);
            }
        });

        idCha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idChaActionPerformed(evt);
            }
        });

        idFun.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idFunActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(51, 153, 255));
        jLabel2.setText("Nome Funcionario:");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(51, 153, 255));
        jLabel3.setText("Nome de sala:");

        campoNomeFuncionarioReserva.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoNomeFuncionarioReservaActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(51, 153, 255));
        jLabel4.setText("CPF FUNCIONARIO:");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 153, 255));
        jLabel5.setText("Tabela de seleção da COPED");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(51, 153, 255));
        jLabel6.setText("CADASTRAR RESERVAS DO DIA");

        cadastrarReservarDoDia.setBackground(new java.awt.Color(0, 153, 255));
        cadastrarReservarDoDia.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        cadastrarReservarDoDia.setForeground(new java.awt.Color(255, 255, 255));
        cadastrarReservarDoDia.setText("RESEVAR");
        cadastrarReservarDoDia.setActionCommand("RESERVAR");
        cadastrarReservarDoDia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cadastrarReservarDoDiaActionPerformed(evt);
            }
        });

        campoNomeSalaReserva.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoNomeSalaReservaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelCadastroDeReservasLayout = new javax.swing.GroupLayout(panelCadastroDeReservas);
        panelCadastroDeReservas.setLayout(panelCadastroDeReservasLayout);
        panelCadastroDeReservasLayout.setHorizontalGroup(
            panelCadastroDeReservasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelCadastroDeReservasLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelCadastroDeReservasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 972, Short.MAX_VALUE)
                    .addGroup(panelCadastroDeReservasLayout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addGroup(panelCadastroDeReservasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelCadastroDeReservasLayout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(idFun, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(24, 24, 24)
                                .addComponent(idCha, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(51, 51, 51))
                            .addGroup(panelCadastroDeReservasLayout.createSequentialGroup()
                                .addGroup(panelCadastroDeReservasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel6)
                                    .addComponent(campoNomeSalaReserva, javax.swing.GroupLayout.PREFERRED_SIZE, 251, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(campoNomeFuncionarioReserva, javax.swing.GroupLayout.PREFERRED_SIZE, 251, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel3))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(panelCadastroDeReservasLayout.createSequentialGroup()
                                .addGroup(panelCadastroDeReservasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(panelCadastroDeReservasLayout.createSequentialGroup()
                                        .addComponent(cadastrarReservarDoDia, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelCadastroDeReservasLayout.createSequentialGroup()
                                        .addGap(0, 0, Short.MAX_VALUE)
                                        .addComponent(jLabel4)))
                                .addGap(18, 18, 18)
                                .addComponent(pesquisaSala, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(pesquisar, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(panelCadastroDeReservasLayout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        panelCadastroDeReservasLayout.setVerticalGroup(
            panelCadastroDeReservasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelCadastroDeReservasLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelCadastroDeReservasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelCadastroDeReservasLayout.createSequentialGroup()
                        .addGroup(panelCadastroDeReservasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(idFun, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(idCha, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(5, 5, 5)))
                .addComponent(campoNomeFuncionarioReserva, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(campoNomeSalaReserva, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelCadastroDeReservasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panelCadastroDeReservasLayout.createSequentialGroup()
                        .addComponent(cadastrarReservarDoDia, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panelCadastroDeReservasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(jLabel4)))
                    .addGroup(panelCadastroDeReservasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(pesquisaSala, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(pesquisar, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 422, Short.MAX_VALUE)
                .addContainerGap())
        );

        panelDevolucao.setBackground(new java.awt.Color(255, 255, 255));

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(0, 153, 255));
        jLabel18.setText("FECHAR RESEVAS");

        campoFuncionarioDevolucao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoFuncionarioDevolucaoActionPerformed(evt);
            }
        });

        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(0, 153, 255));
        jLabel19.setText("Nome do Funcionario:");

        jLabel20.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(0, 153, 255));
        jLabel20.setText("Sala:");

        devolverChave.setBackground(new java.awt.Color(0, 153, 255));
        devolverChave.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        devolverChave.setForeground(new java.awt.Color(255, 255, 255));
        devolverChave.setText("FECHAR");
        devolverChave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                devolverChaveActionPerformed(evt);
            }
        });

        tabelaDevolucao.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Id", "Funcionario", "Sala", "Data", "Hora", "Entregue"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tabelaDevolucao.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                selecionarNaTabelaDevolucao(evt);
            }
        });
        jScrollPane5.setViewportView(tabelaDevolucao);

        javax.swing.GroupLayout panelDevolucaoLayout = new javax.swing.GroupLayout(panelDevolucao);
        panelDevolucao.setLayout(panelDevolucaoLayout);
        panelDevolucaoLayout.setHorizontalGroup(
            panelDevolucaoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelDevolucaoLayout.createSequentialGroup()
                .addGap(2, 2, 2)
                .addGroup(panelDevolucaoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(devolverChave, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(campoSalaDevolucao, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(campoFuncionarioDevolucao, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 369, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 975, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelDevolucaoLayout.setVerticalGroup(
            panelDevolucaoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelDevolucaoLayout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addComponent(jLabel18)
                .addGap(16, 16, 16)
                .addComponent(jLabel19)
                .addGap(1, 1, 1)
                .addComponent(campoFuncionarioDevolucao, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel20)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(campoSalaDevolucao, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(devolverChave, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 422, Short.MAX_VALUE)
                .addGap(12, 12, 12))
        );

        panelReservasT.setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setBackground(new java.awt.Color(51, 153, 255));

        tabelaReservaInfo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "ID FUNCIONARIO", "NOME", "SALA", "DISPONIVEL", "HORARIO RESERVA", "HORA ENTREGUE", "ENTREGUE"
            }
        ));
        tabelaReservaInfo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabelaReservaInfoMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tabelaReservaInfo);

        reservasFeitas.setBackground(new java.awt.Color(51, 153, 255));
        reservasFeitas.setText("Reservas Feitas");

        jButton1.setText("jButton1");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(408, 408, 408)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(reservasFeitas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 964, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 20, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(reservasFeitas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43)
                .addComponent(jButton1)
                .addContainerGap(138, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout panelReservasTLayout = new javax.swing.GroupLayout(panelReservasT);
        panelReservasT.setLayout(panelReservasTLayout);
        panelReservasTLayout.setHorizontalGroup(
            panelReservasTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        panelReservasTLayout.setVerticalGroup(
            panelReservasTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panelMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panelCadastroDeReservas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(204, 204, 204)
                    .addComponent(panelDevolucao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(193, 193, 193)
                    .addComponent(panelReservasT, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGap(16, 16, 16)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(panelCadastroDeReservas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panelMenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(panelDevolucao, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(panelReservasT, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public void limparCamposReservas(){
        campoNomeFuncionarioReserva.setText("");
        campoNomeSalaReserva.setText("");
        setIdFuncionarioSelec(0);
        setIdChaveSelec(0);
    }
    private void BtnCadastrarReservaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnCadastrarReservaActionPerformed
       panelCadastroDeReservas.setVisible(true);
       panelDevolucao.setVisible(false);
       panelReservasT.setVisible(false);
       idCha.setVisible(false);
       idFun.setVisible(false);
       PreencherTabelaSelecao();
       limparCamposReservas();
    }//GEN-LAST:event_BtnCadastrarReservaActionPerformed

    public void limparCamposDevol(){
        campoFuncionarioDevolucao.setText("");
        campoSalaDevolucao.setText("");
        setIdReservaSelect(0);
    }
    private void BtnDevolucaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnDevolucaoActionPerformed
        panelDevolucao.setVisible(true);
        panelReservasT.setVisible(false);
        panelCadastroDeReservas.setVisible(false);
        PreencherTabelaDevolucao();
        limparCamposDevol();
       
    }//GEN-LAST:event_BtnDevolucaoActionPerformed

    private void campoNomeFuncionarioReservaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoNomeFuncionarioReservaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_campoNomeFuncionarioReservaActionPerformed

    private void idFunActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idFunActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_idFunActionPerformed

    private void idChaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idChaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_idChaActionPerformed

    private void pesquisaSalaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pesquisaSalaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pesquisaSalaActionPerformed

    private void campoNomeSalaReservaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoNomeSalaReservaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_campoNomeSalaReservaActionPerformed

    private void BtnTodasResevasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnTodasResevasActionPerformed
        // TODO add your handling code here:
        
       //   ReservaController reservaController = new ReservaController();
   // boolean sucesso = reservaController.atualizarReservasInfo();

   // if (sucesso) {
     //   listarReservas(); // Chama o método para listar as reservas e atualizar a tabela
  //  } else {
       // JOptionPane.showMessageDialog(this, "Erro ao atualizar a tabela.");
   // }
  // Atualizar as reservas antes de exibir o painel 
 // Atualizar as reservas antes de exibir o painel
ReservaController reservaController = new ReservaController(); 

boolean sucesso = reservaController.atualizarReservasInfo(); 

if (sucesso) { 
    // Listar reservas no painel (supondo que tenha um método para isso)
    listarReservasNoPainel(); // Supondo que o método listarReservasNoPainel esteja público 

    // Tornar o painel visível
    panelReservasT.setVisible(true); 
} else { 
    JOptionPane.showMessageDialog(this, "Erro ao atualizar as reservas."); 
     panelReservasT.setVisible(true); 
}

        
  // Crie uma instância da tela TelaReservas 
  //TelaReservas telaReservas = new TelaReservas(); 
// Exibir a tela TelaReservas 
//telaReservas.setVisible(true); 
// Fechar ou ocultar a tela de menu atual, se necessário 
 this.dispose(); // Fechar a tela de menu
 this.setVisible(false); // Ocultar a tela de menu      
               
    }//GEN-LAST:event_BtnTodasResevasActionPerformed

    private int idFuncionarioSelec;
    private int idChaveSelec;
    public int getIdFuncionarioSelec() {
        return idFuncionarioSelec;
    }
    public void setIdFuncionarioSelec(int idFuncionarioSelec) {
        this.idFuncionarioSelec = idFuncionarioSelec;
    }
    public int getIdChaveSelec() {
        return idChaveSelec;
    }
    public void setIdChaveSelec(int idChaveSelec) {
        this.idChaveSelec = idChaveSelec;
    }
    
    
    private void tabelaSelecaoClick(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabelaSelecaoClick
         // TODO add your handling code here:
        
        // capturar a linha que o usuario clicou
        int linhaselecionada = TabelaDeSelecao.getSelectedRow();
        
        // verificar se o usuario clicou em alguma linha
        if (linhaselecionada>=0){
          // definir modelo padrão da tabela
          DefaultTableModel modelotabela = (DefaultTableModel) TabelaDeSelecao.getModel();
          this.idFuncionarioSelec = Integer.parseInt(modelotabela.getValueAt(linhaselecionada,4).toString());
          this.idChaveSelec = Integer.parseInt(modelotabela.getValueAt(linhaselecionada, 5).toString());
          String funcionario = modelotabela.getValueAt(linhaselecionada, 0).toString();
          String sala = modelotabela.getValueAt(linhaselecionada, 1).toString();
          //String periodo = modelotabela.getValueAt(linhaselecionada, 1).toString();
          campoNomeFuncionarioReserva.setText(funcionario);
          campoNomeSalaReserva.setText(sala);

          System.err.println(idFuncionarioSelec);
        }// fim do if
    }//GEN-LAST:event_tabelaSelecaoClick

    private void cadastrarReservarDoDiaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cadastrarReservarDoDiaActionPerformed
    if (getIdFuncionarioSelec() == 0 || getIdChaveSelec() == 0) {
    JOptionPane.showMessageDialog(null, "Faça uma seleção na tabela");
} else {
    DateTimeFormatter formatar = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    String dataAtualFormatada = LocalDate.now().format(formatar);

    DateTimeFormatter formatarHora = DateTimeFormatter.ofPattern("HH:mm");
    String horaAtualFormatada = LocalTime.now().format(formatarHora);
    Reserva r = new Reserva();
    r.setIdFuncionario(idFuncionarioSelec);
    r.setIdChave(idChaveSelec);
    r.setDataReserva(dataAtualFormatada);
    r.setHoraReserva(horaAtualFormatada);
    r.setEntregue(false);

    ReservaController dao = new ReservaController();
    boolean inserir = dao.inserirReserva(r);

    if (inserir) {
        JOptionPane.showMessageDialog(this, "Reserva cadastrada com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
    } else {
        JOptionPane.showMessageDialog(this, "Não foi possível cadastrar a reserva. A chave já está reservada.", "Erro", JOptionPane.ERROR_MESSAGE);
        limparCamposReservas();
    }

    System.err.println(r.toString());
}

    }//GEN-LAST:event_cadastrarReservarDoDiaActionPerformed

    private void devolverChaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_devolverChaveActionPerformed
        if(getIdReservaSelect() == 0){
           JOptionPane.showMessageDialog (this,"selecione uma reserva na tabela!");  
        }else{
           DateTimeFormatter formatar = DateTimeFormatter.ofPattern("dd/MM/yyyy");
           String data = LocalDate.now().format(formatar);
           
           DateTimeFormatter formatarHora = DateTimeFormatter.ofPattern("HH:mm");
           String hora = LocalTime.now().format(formatarHora);
           
           ReservaController dao = new ReservaController();
            boolean devolucao = dao.devolucao(idReservaSelect, data, hora);
            
            if(!devolucao){
                 JOptionPane.showMessageDialog(this, "Erro ao realizar devolução!", "Erro", JOptionPane.ERROR_MESSAGE);
                 
            }else{
                JOptionPane.showMessageDialog(this, "Devolução realizada com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                PreencherTabelaDevolucao();
                limparCamposDevol();
            }       
        }
    }//GEN-LAST:event_devolverChaveActionPerformed

    private void campoFuncionarioDevolucaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoFuncionarioDevolucaoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_campoFuncionarioDevolucaoActionPerformed

    private int idReservaSelect; 
    public int getIdReservaSelect() {
        return idReservaSelect;
    }
    public void setIdReservaSelect(int idReservaSelect) {
        this.idReservaSelect = idReservaSelect;
    }
    private void selecionarNaTabelaDevolucao(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_selecionarNaTabelaDevolucao
         // TODO add your handling code here:
        
        // capturar a linha que o usuario clicou
        int linhaselecionada = tabelaDevolucao.getSelectedRow();
        
        // verificar se o usuario clicou em alguma linha
        if (linhaselecionada>=0){
          // definir modelo padrão da tabela
          DefaultTableModel modelotabela = (DefaultTableModel) tabelaDevolucao.getModel();
          this.idReservaSelect = Integer.parseInt(modelotabela.getValueAt(linhaselecionada,0).toString());
          String funcionario = modelotabela.getValueAt(linhaselecionada, 1).toString();
          String sala = modelotabela.getValueAt(linhaselecionada, 2).toString();
          campoFuncionarioDevolucao.setText(funcionario);
          campoSalaDevolucao.setText(sala);
        }// fim do if
    }//GEN-LAST:event_selecionarNaTabelaDevolucao

    private void tabelaReservaInfoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabelaReservaInfoMouseClicked
        // TODO add your handling code here:
   /*     // Capturar a linha que o usuário clicou
int linhaSelecionada = tabelaReservaInfo.getSelectedRow(); 

// Verificar se o usuário clicou em alguma linha
if (linhaSelecionada >= 0) { 
    // Definir modelo padrão da tabela
    DefaultTableModel modeloTabela = (DefaultTableModel) tabelaReservaInfo.getModel(); 

    // Preencher os campos de texto com os dados da linha selecionada
    campoIdFuncionario.setText(modeloTabela.getValueAt(linhaSelecionada, 0).toString()); 
    campoNomeFuncionario.setText(modeloTabela.getValueAt(linhaSelecionada, 1).toString()); 
    campoNomeSala.setText(modeloTabela.getValueAt(linhaSelecionada, 2).toString()); 
    campoDisponibilidade.setText(modeloTabela.getValueAt(linhaSelecionada, 3).toString()); 
    campoHoraReserva.setText(modeloTabela.getValueAt(linhaSelecionada, 4).toString()); 
    campoHoraEntrega.setText(modeloTabela.getValueAt(linhaSelecionada, 5).toString()); 
    checkBoxEntregue.setSelected(modeloTabela.getValueAt(linhaSelecionada, 6).toString().equals("Sim")); 
}
*/
    }//GEN-LAST:event_tabelaReservaInfoMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Menu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JToggleButton BtnCadastrarReserva;
    private javax.swing.JToggleButton BtnDevolucao;
    private javax.swing.JToggleButton BtnTodasResevas;
    private javax.swing.JTable TabelaDeSelecao;
    private javax.swing.JButton cadastrarReservarDoDia;
    private javax.swing.JTextField campoFuncionarioDevolucao;
    private javax.swing.JTextField campoNomeFuncionarioReserva;
    private javax.swing.JTextField campoNomeSalaReserva;
    private javax.swing.JTextField campoSalaDevolucao;
    private javax.swing.JButton devolverChave;
    private javax.swing.JLabel iconUsuario;
    private javax.swing.JTextField idCha;
    private javax.swing.JTextField idFun;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JPanel panelCadastroDeReservas;
    private javax.swing.JPanel panelDevolucao;
    private javax.swing.JPanel panelMenu;
    private javax.swing.JPanel panelReservasT;
    private javax.swing.JTextField pesquisaSala;
    private javax.swing.JButton pesquisar;
    private javax.swing.JTextField reservasFeitas;
    private javax.swing.JTable tabelaDevolucao;
    private javax.swing.JTable tabelaReservaInfo;
    // End of variables declaration//GEN-END:variables
}
