/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package main;




import Controller.Conexao;
import View.Menu;
import View.MenuCooped;
import View.loginTela;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class ReservaDeSalas {

    public static void main(String[] args) {
       MenuCooped menu = new MenuCooped();
        menu.setVisible(true);
       // Menu menu = new Menu();
       // menu.setVisible(true);
    // loginTela telaLogin = new loginTela(); 
    //telaLogin.setVisible(true);
     
            
    }
}
